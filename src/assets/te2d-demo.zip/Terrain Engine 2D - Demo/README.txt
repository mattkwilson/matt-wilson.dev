Terrain Engine 2D - created by Matthew Wilson

This folder includes a demo build of an example Terrain Engine 2D project for Windows, Mac and Linux (only tested on Windows).

Latest Showcase Video: https://www.youtube.com/watch?v=aEjtgVMkfxA